<?php
define('THEMESEDITOR_CTHEME','githubsync');
define('THEMESEDITOR_CFILE','githubsync_show.php');
define('CODEMIRROR_THEME','ambiance');
define('THEMESEDITOR_EDITOR_THEMES',"ambiance,blackboard,cobalt,eclipse,elegant,erlang-dark,lesser-dark,monokai,neat,night,rubyblue,twilight,vibrant-ink,xq-dark");
